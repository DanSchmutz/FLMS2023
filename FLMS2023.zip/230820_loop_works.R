# for loop to cycle through the penguin reports
# 230810
# Dan Schmutz


library(tidyverse)
library(rmarkdown)

species_list<-unique(penguins$species)
species_list<-as.character(species_list)
rmarkdown::render('rmds/epenguins_v2_picker_prepicker.Rmd')

# a function for rendering
render_report = function(species_sel) {
  rmarkdown::render(
    'rmds/epenguins_v2_picker_prepicker.Rmd', params = list(
      species = species_sel),
     output_file = paste0("Report-", species_sel,".pdf")
  )
}


render_report("Chinstrap")


for(i in species_list){
  render_report(as.character(i))
  
}
