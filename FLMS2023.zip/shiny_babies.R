library(shiny)
library(babynames)
library(tidyverse)

all_the_names<-babynames %>% select(name) %>% distinct()
all_the_genders<-babynames %>% select(sex) %>% distinct()


ui <- fluidPage(
  selectInput(inputId = "gender_selected", label = "Gender", choices = all_the_genders$sex),
  selectizeInput(inputId = "name_selected", label = "Name", choices=NULL),
  plotOutput("plot")
)

server <- function(input, output, session) {
  updateSelectizeInput(session, "name_selected", choices = as.character(all_the_names$name), server = TRUE)
  # create reactive filter
  dataset <- reactive({
    babynames %>%
      filter(name==input$name_selected & sex==input$gender_selected) %>% 
      select(-name,-sex)
  })
  
  peak_year <- reactive({
    dataset() %>% arrange(desc(prop)) %>% slice(1) %>% select(year)
  })
  
  output$plot <- renderPlot({
    ggplot(dataset(),aes(x=year,y=prop))+geom_line()+geom_point()+
      labs(title=paste("Percentage of",input$gender_selected,"named",input$name_selected,"by birth year in the U.S."),
           subtitle=paste("Peak ",input$name_selected," is ",year(Sys.Date())-peak_year()," years old in ",year(Sys.Date()),".", sep=""),
           x="Year", y="Proportion")+theme_grey(base_size = 14)+scale_y_continuous(labels = scales::percent)
  }, res=96, height = 600, width=900)
  
}
shinyApp(ui, server)