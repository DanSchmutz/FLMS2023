# playing with widgets
# 230826
# Dan Schmutz



library(tidyverse)
library(plotly)

# great visualization of crosstalk brushing
ggplot(mpg, aes(displ, hwy)) + geom_point()

m <- highlight_key(mpg)
p <- ggplot(m, aes(displ, hwy)) + geom_point()
gg <- highlight(ggplotly(p), "plotly_selected")
crosstalk::bscols(gg, DT::datatable(m), device="lg")


# highlighting the corvette

library(ggforce)
ggplot(mpg, aes(displ, hwy)) + 
  geom_point() +
  geom_mark_hull(aes(filter = model == "corvette", label = model)) +
  labs(
    title = "Fuel economy from 1999 to 2008 for 38 car models",
    caption = "Source: https://fueleconomy.gov/",
    x = "Engine Displacement", 
    y = "Miles Per Gallon"
  )


# plotly_data, plotly_build and plotly_json
p<-plot_ly(diamonds, x = ~cut, color = ~clarity, colors = "Accent")
print(p)
plotly_data(p)


# interactive label movement

plot_ly(mpg, x=~displ, y=~hwy) %>% 
  config(edits = list(annotationPosition = TRUE))

# ideas for annotations
# https://plotly.com/r/text-and-annotations/

# visualizing multiple discrete distributions
plot_ly(diamonds, x = ~cut, color = ~clarity) %>%
  add_histogram()

# number of diamonds by cut and clarity (n)
cc <- count(diamonds, cut, clarity)
# number of diamonds by cut (nn)
cc2 <- left_join(cc, count(cc, cut, wt = n, name = 'nn'))
cc2 %>%
  mutate(prop = n / nn) %>%
  plot_ly(x = ~cut, y = ~prop, color = ~clarity) %>%
  add_bars() %>%
  layout(barmode = "stack")

# above is a special type of mosaic plot, here is a mosaic plot that also incorporates
# info about frequency of each cut on x axis
library(ggmosaic)
p <- ggplot(data = cc) +
  geom_mosaic(aes(weight = n, x = product(cut), fill = clarity))
ggplotly(p)

# 3 d scatterplot. Amazing
plot_ly(mpg, x = ~cty, y = ~hwy, z = ~cyl) %>%
  add_markers(color = ~cyl)

# if you wanted to clean up the axes titles, they are in the scene definition:
plot_ly(mpg, x = ~cty, y = ~hwy, z = ~cyl) %>%
  add_markers(color = ~displ) %>%
  layout(
    scene = list(
      xaxis = list(title = "MPG city"),
      yaxis = list(title = "MPG highway"),
      zaxis = list(title = "Number of cylinders")
    )
  )

plotlympg<-plot_ly(mpg, x = ~cty, y = ~hwy, z = ~cyl) %>%
  add_markers(color = ~displ) %>%
  layout(
    scene = list(
      xaxis = list(title = "MPG city"),
      yaxis = list(title = "MPG highway"),
      zaxis = list(title = "Number of cylinders")
    )
  )

# can we package this as a widget to email our friends?
htmlwidgets::saveWidget(plotlympg, "plotlympg.html")


# before we leave 3d, we have to check out the volcano
glimpse(volcano)
volcano
dim(volcano)
class(volcano)
# a numeric matrix
x <- seq_len(nrow(volcano)) #+ 100
y <- seq_len(ncol(volcano)) #+ 500
plot_ly() %>% add_surface(x = ~x, y = ~y, z = ~volcano)

# what would a log transform of a volcano look like?
lnv<-log(volcano)
x <- seq_len(nrow(lnv)) #+ 100
y <- seq_len(ncol(lnv)) #+ 500
plot_ly() %>% add_surface(x = ~x, y = ~y, z = ~lnv)


# ggpairs from ggaly for splom plots
pm <- GGally::ggpairs(iris, aes(color = Species))
class(pm)
ggplotly(pm)

# tremendous amount of info in one graph

# skip this one
# trelliscope extends idea of trellis graphs
library(trelliscopejs)
data(gapminder, package = "gapminder")

qplot(year, lifeExp, data = gapminder) +
  xlim(1948, 2011) + ylim(10, 95) + theme_bw() +
  facet_trelliscope(~ country + continent,
                    nrow = 2, ncol = 6, width = 300, 
                    as_plotly = TRUE, 
                    plotly_args = list(dynamicTicks = T),
                    plotly_cfg = list(displayModeBar = F)
  )

# interesting but couldn't get all the features to work

# animation, set the frame variable in the geom_point call

library(gapminder)
data(gapminder, package = "gapminder")
gg <- ggplot(gapminder, aes(gdpPercap, lifeExp, color = continent)) +
  geom_point(aes(size = pop, frame = year, ids = country)) +
  scale_x_log10()
ggplotly(gg)
# amazing viz



# can end here or see how much time we have
# client side highlighting

library(crosstalk)

# generally speaking, use a "unique" key for filter, 
# especially when you have multiple filters!
tx <- highlight_key(txhousing)
gg <- ggplot(tx) + geom_line(aes(date, median, group = city))
filter <- bscols(
  filter_select("id", "Select a city", tx, ~city),
  ggplotly(gg, dynamicTicks = TRUE),
  widths = c(12, 12)
)

tx2 <- highlight_key(txhousing, ~city, "Select a city")
gg <- ggplot(tx2) + geom_line(aes(date, median, group = city))
select <- highlight(
  ggplotly(gg, tooltip = "city"), 
  selectize = TRUE, persistent = TRUE
)
bscols(filter, select)


# filtering from a map
library(leaflet)

eqs <- highlight_key(quakes)
stations <- filter_slider(
  "station", "Number of Stations", 
  eqs, ~stations
)

p <- plot_ly(eqs, x = ~depth, y = ~mag) %>% 
  add_markers(alpha = 0.5) %>% 
  highlight("plotly_selected")

map <- leaflet(eqs) %>% 
  addTiles() %>% 
  addCircles()

bscols(
  widths = c(6, 6, 3), 
  p, map, stations
)

# linking animated views
g <- highlight_key(gapminder, ~continent)
gg <- ggplot(g, aes(gdpPercap, lifeExp, 
                    color = continent, frame = year)) +
  geom_point(aes(size = pop, ids = country)) +
  geom_smooth(se = FALSE, method = "lm") +
  scale_x_log10()
highlight(ggplotly(gg), "plotly_hover")


# querying across trellis displays
library(dplyr)
cities <- c("Galveston", "Midland", "Odessa", "South Padre Island")
txsmall <- txhousing %>%
  select(city, year, month, median) %>%
  filter(city %in% cities)

txsmall %>%
  highlight_key(~year) %>% {
    ggplot(., aes(month, median, group = year)) + geom_line() +
      facet_wrap(~city, ncol = 2)
  } %>%
  ggplotly(tooltip = "year")

# statistical queries
m <- highlight_key(mpg)
p <- ggplot(m, aes(displ, hwy, colour = class)) +
  geom_point() +
  geom_smooth(se = FALSE, method = "lm")
ggplotly(p) %>% highlight("plotly_hover")

# also found I could override the tooltip: ggplotly(p, tooltip= "class")


# interactive plotly on the server side with shiny

library(shiny)
library(plotly)

ui <- fluidPage(
  selectizeInput(
    inputId = "cities", 
    label = "Select a city", 
    choices = unique(txhousing$city), 
    selected = "Abilene",
    multiple = TRUE
  ),
  plotlyOutput(outputId = "p")
)

server <- function(input, output, ...) {
  output$p <- renderPlotly({
    plot_ly(txhousing, x = ~date, y = ~median) %>%
      filter(city %in% input$cities) %>%
      group_by(city) %>%
      add_lines()
  })
}

shinyApp(ui, server)
# nice!



# shiny for linking heatmap and scatterplot. nice
library(shiny)

# cache computation of the correlation matrix
correlation <- round(cor(mtcars), 3)

ui <- fluidPage(
  plotlyOutput("heat"),
  plotlyOutput("scatterplot")
)

server <- function(input, output, session) {
  
  output$heat <- renderPlotly({
    plot_ly(source = "heat_plot") %>%
      add_heatmap(
        x = names(mtcars), 
        y = names(mtcars), 
        z = correlation
      )
  })
  
  output$scatterplot <- renderPlotly({
    # if there is no click data, render nothing!
    clickData <- event_data("plotly_click", source = "heat_plot")
    if (is.null(clickData)) return(NULL)
    
    # Obtain the clicked x/y variables and fit linear model
    vars <- c(clickData[["x"]], clickData[["y"]])
    d <- setNames(mtcars[vars], c("x", "y"))
    yhat <- fitted(lm(y ~ x, data = d))
    
    # scatterplot with fitted line
    plot_ly(d, x = ~x) %>%
      add_markers(y = ~y) %>%
      add_lines(y = ~yhat) %>%
      layout(
        xaxis = list(title = clickData[["x"]]), 
        yaxis = list(title = clickData[["y"]]), 
        showlegend = FALSE
      )
  })
  
}

shinyApp(ui, server)

