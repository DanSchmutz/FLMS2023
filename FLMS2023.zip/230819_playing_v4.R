# working on interactivity ideas for R workshop
# 230819
# Dan Schmutz



library(tidyverse)
library(plotly)
library(palmerpenguins)
library(htmlwidgets)
library(rgl)
library(leaflet)
library(sf)
library(skimr)
library(rvest)

data()

glimpse(penguins)

ggplot(penguins, aes(x=body_mass_g, y= bill_length_mm, color=species))+
  geom_point()+stat_smooth(method='lm')


p1<-ggplot(penguins, aes(x=body_mass_g, y= bill_length_mm, color=species))+
  geom_point()+stat_smooth(method='lm')

ggplotly(p1)

# this worked!
saveWidget(ggplotly(p1), file="peng1.html")


# how about a 3d view
# https://r-graph-gallery.com/3d_scatter_plot.html

pd<-penguins

# Add a new column with color
mycolors <- c('red', 'green', 'blue')
pd$color <- mycolors[ as.numeric(pd$species) ]

# this worked
# Plot
plot3d( 
  x=pd$`body_mass_g`, y=pd$`bill_length_mm`, z=pd$`bill_depth_mm`, 
  col = pd$color, 
  type = 's', 
  radius = 15,
  xlab="Body Mass (g)", ylab="Bill Length (mm)", zlab="Bill Depth (mm)")

rglwidget(
  plot3d( 
    x=pd$`body_mass_g`, y=pd$`bill_length_mm`, z=pd$`bill_depth_mm`, 
    col = pd$color, 
    type = 's', 
    radius = 15,
    xlab="Body Mass (g)", ylab="Bill Length (mm)", zlab="Bill Depth (mm)")
)

rglwidget()
htmlwidgets::saveWidget(rglwidget(width = 1040, height = 1040), 
                        file = "outputs/widgets/scatter3dpeng.html",
                        libdir = "libs",
                        selfcontained = TRUE
)

# list of htmlwidgets
# https://www.htmlwidgets.org/showcase_rglwidget.html


# leaflet
#https://geodata.dep.state.fl.us/datasets/FDEP::eric-pfas-sites-1/about

pfas <- read_sf("data/shapefiles/Eric_PFAS_Sites.shp")
pfas
st_crs(pfas)
st_transform(pfas,)
pfaslatlon <- st_transform(pfas, crs = 4326)
st_crs(pfaslatlon)
View(pfaslatlon)
skim(pfas)

m <- leaflet() %>% 
  addTiles() %>% 
  setView( lng = -80.91007991830875, lat = 24.7772522667228, zoom = 300 ) %>% 
  addProviderTiles("Esri.WorldImagery")
m

m %>%
  # add pfas
  addMarkers(
    data = pfaslatlon, label = pfaslatlon$SITE_NAME)
    
    
    
# can we do some webscraping to get dive sites?
# https://key-west-fishing.link/florida-keys-wrecks-gps.htm

page <- read_html("https://key-west-fishing.link/florida-keys-wrecks-gps.htm")
page    
 
tbls <- html_nodes(page, "table")
tbls

tbls_ls <- page %>%
  html_nodes("table") %>%
  html_table(fill = TRUE)

tbls_ls

str(tbls_ls)

dim(tbls_ls)

tbldf<-data.frame(tbls_ls)

tbldf[1,1]

glimpse(tbldf)
tbldf[1,]
colnames(tbldf)<-tbldf[1,]
reefs<-tbldf[-1,]

head(reefs)
reefs$lat<-as.numeric(reefs$LATITUDE)/100
reefs$lon<-as.numeric(reefs$LONGITUDE)/-100

reefsknown<-reefs %>% drop_na(lat,lon)

reefs_sf <- st_as_sf(reefsknown, coords = c("lon","lat"))
st_crs(reefs_sf)
reefs_sf <- st_set_crs(reefs_sf, 4326) 

m <- leaflet() %>% 
  addTiles() %>% 
  setView( lng = -80.91007991830875, lat = 24.7772522667228, zoom = 300 ) %>% 
    # add different provider tiles
  addProviderTiles(
    "OpenStreetMap",
    # give the layer a name
    group = "OpenStreetMap"
  ) %>%
  addProviderTiles(
    "Esri.WorldStreetMap",
    group = "Esri.WorldStreetMap"
  ) %>%
  addProviderTiles(
    "Wikimedia",
    group = "Wikimedia"
  ) %>%
  addProviderTiles(
    "CartoDB.Positron",
    group = "CartoDB.Positron"
  ) %>%
  addProviderTiles(
    "Esri.WorldImagery",
    group = "Esri.WorldImagery"
  ) %>%
  # add a layers control
  addLayersControl(
    baseGroups = c(
      "Esri.WorldImagery","OpenStreetMap",
      "Esri.WorldStreetMap",
      "Wikimedia", "CartoDB.Positron"
    ),
    # position it on the topleft
    position = "topleft"
  ) 
m

m %>%
  # add pfas
  addMarkers(
    data = pfaslatlon, label = pfaslatlon$SITE_NAME)


m %>%
  # add wrecks
  addMarkers(
    data = reefs_sf, label = paste("REEF NAME: ",reefs_sf$`REEF NAME`,"/",
                                   "DESCRIPTION: ",reefs_sf$DESCRIPTION,"/",
                                   "DEPTH: ",reefs_sf$DEPTH)) %>% 
  addPopups(lng = -80.91007991830875, lat = 24.7772522667228, "Hawks Cay Resort",
            options = popupOptions(closeButton = FALSE)
  )

  

# sharing our reefmap
map1 <- leaflet() %>% 
  addTiles() %>% 
  setView( lng = -80.91007991830875, lat = 24.7772522667228, zoom = 300 ) %>% 
  # add different provider tiles
  addProviderTiles(
    "OpenStreetMap",
    # give the layer a name
    group = "OpenStreetMap"
  ) %>%
  addProviderTiles(
    "Esri.WorldStreetMap",
    group = "Esri.WorldStreetMap"
  ) %>%
  addProviderTiles(
    "Wikimedia",
    group = "Wikimedia"
  ) %>%
  addProviderTiles(
    "CartoDB.Positron",
    group = "CartoDB.Positron"
  ) %>%
  addProviderTiles(
    "Esri.WorldImagery",
    group = "Esri.WorldImagery"
  ) %>%
  # add a layers control
  addLayersControl(
    baseGroups = c(
      "Esri.WorldImagery","OpenStreetMap",
      "Esri.WorldStreetMap",
      "Wikimedia", "CartoDB.Positron"
    ),
    # position it on the topleft
    position = "topleft"
  ) %>%
  # add wrecks
  addMarkers(
    data = reefs_sf, label = paste("REEF NAME: ",reefs_sf$`REEF NAME`,"/",
                                   "DESCRIPTION: ",reefs_sf$DESCRIPTION,"/",
                                   "DEPTH: ",reefs_sf$DEPTH)) %>% 
  addPopups(lng = -80.91007991830875, lat = 24.7772522667228, "Hawks Cay Resort",
            options = popupOptions(closeButton = FALSE)
  )


# can save the map as html for someone else to open on their computer
htmlwidgets::saveWidget(map1, "map1.html", selfcontained = T)


