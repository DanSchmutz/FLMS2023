library(shiny)
library(palmerpenguins)
library(tidyverse)
library(DT)

all_the_species<-penguins %>% select(species) %>% distinct()


ui <- fluidPage(
  selectInput(inputId = "species_selected", label = "Species", multiple= TRUE, choices = all_the_species$species),
  plotOutput("plot"),
  DTOutput("table")
)

server <- function(input, output, session) {
  # create reactive filter
  dataset <- reactive({
    penguins %>%
      dplyr::filter(species %in% input$species_selected)
  })

  
  output$plot <- renderPlot({
    ggplot(dataset(),aes(x=bill_length_mm, y=flipper_length_mm, group=species, color=species))+
      geom_point()+stat_smooth(method='lm')+labs(title="Flipper vs. Bill Length for Some Penguins",
                                                 x="Bill Length (mm)", y= "Flipper Length (mm)")+
      theme_grey(base_size = 14)
  }, res=96)
  
  output$table <- renderDT(dataset())
  
}

shinyApp(ui, server)

# had to archive and delete one of my apps, but got it deployed:
# https://nonrandom.shinyapps.io/peng_v1/
